# chrome-bookmark-extension
A simple way to organize chrome bookmarks

# Instaling the extension

1. Download and unzip the .zip file
2. Open chrome://extensions
3. Click the switch at the top right 
4. Click "Load Unpacked" and navigate to the folder you unzipped the file to, and upload it
5. Done! You can activate the extension by clicking the extension button in the top right next to the URL bar, and clicking on the extenion
